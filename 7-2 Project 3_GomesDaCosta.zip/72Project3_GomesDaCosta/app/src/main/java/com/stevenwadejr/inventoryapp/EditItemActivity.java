package com.stevenwadejr.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NavUtils;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//Created and add items
public class EditItemActivity extends AppCompatActivity {

	public static final String EXTRA_ITEM = "com.stevenwadejr.inventoryapp.item";

	InventoryActivity inventoryActivity;

	EditText editName;
	EditText editQuantity;

	Button saveButton;
	Button deleteButton;

	private Item item;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
		setContentView(R.layout.activity_edit_item);

		inventoryActivity = InventoryActivity.getInstance(this);

		editName = findViewById(R.id.editItemName);
		editQuantity = findViewById(R.id.editQuantity_edit);
		deleteButton = findViewById(R.id.deleteItemBtn);
		saveButton = findViewById(R.id.saveItem);

		deleteButton.setVisibility(View.GONE);
		saveButton.setEnabled(false);

		int initialQuantity = 0;

		Item item = (Item) getIntent().getSerializableExtra(EXTRA_ITEM);
		if (item != null) {
			this.item = item;
			editName.setText(item.getName());
			initialQuantity = item.getQuantity();
			deleteButton.setVisibility(View.VISIBLE);
		}

		editQuantity.setText(String.valueOf(initialQuantity));

		editName.addTextChangedListener(textWatcher);
		editQuantity.addTextChangedListener(textWatcher);
	}

	//Check for any changes in item's name
	private final TextWatcher textWatcher = new TextWatcher() {
		@Override
		public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		}

		@Override
		public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
			saveButton.setEnabled(!getEditName().isEmpty());
		}

		@Override
		public void afterTextChanged(Editable s) {
		}
	};

	//Save item to database
	public void handleSaveItem(View view) {
		boolean saved;

		// If item exists, update it
		if (item != null) {
			item.setName(getEditName());
			item.setQuantity(getEditQuantity());
			saved = inventoryActivity.updateItem(item);
		} else {
			// If the item does not exist, create it to the database
			saved = inventoryActivity.addItem(getEditName(), getEditQuantity());
		}

		//If the item is saved successfully
		if (saved) {
			NavUtils.navigateUpFromSameTask(this);
			//If the item is not saved successfully
		} else {
			Toast.makeText(EditItemActivity.this, R.string.save_error, Toast.LENGTH_SHORT).show();
		}
	}

	//Handling deleting an item
	public void handleDeleteItem(View view) {
		new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert)
				.setTitle(R.string.delete_confirmation_title).setMessage(R.string.delete_confirmation)
				.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// Delete the item from the database
						boolean deleted = inventoryActivity.deleteItem(item);
						finish();

						if (deleted) {
							NavUtils.navigateUpFromSameTask(EditItemActivity.this);
						} else {
							Toast.makeText(EditItemActivity.this, R.string.delete_error, Toast.LENGTH_SHORT).show();
						}
					}
				}).setNegativeButton("No", null).show();
	}

	//Increase item's quantity by 1
	public void incrementQuantity(View view) {
		editQuantity.setText(String.valueOf(getEditQuantity() + 1));
	}

	//Decrease item's quantity by 1
	public void decrementQuantity(View view) {
		editQuantity.setText(String.valueOf(Math.max(0, getEditQuantity() - 1)));
	}


	private String getEditName() {
		Editable name = editName.getText();
		return name != null ? name.toString().trim() : "";
	}


	private int getEditQuantity() {
		String rawValue = editQuantity.getText().toString().replaceAll("[^\\d.]", "").trim();
		int quantity = rawValue.isEmpty() ? 0 : Integer.parseInt(rawValue);

		return Math.max(quantity, 0);
	}
}
